function [Psi_mat,Phi_mat,theta_1,theta_2,zeta_1,zeta_2,zeta_3,zeta_4,zeta_5,zeta_6] = Psis_public_and_private(lambda_1,lambda_2,rho,tau_1,tau_2,tau_eps,tau_eta,...
    beta_1,beta_2,varphi_1,varphi_2,alpha_11,alpha_12,alpha_21,alpha_22,gamma_11,gamma_12,gamma_21,gamma_22,delta_11,delta_12,delta_21,delta_22,z_vector)

%% Matrix C(z) and Polynomial C(z) (necessary to obtain the roots, look at mathematica for the analytical expression)
% In order to obtain the roots, write z as a symbol (for a moment)
syms z
C_11 = 1-delta_11/(z*tau_eta)-gamma_11/tau_eta;
C_12 = -lambda_1*tau_eps*(alpha_11+gamma_11*z)/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2);
C_13 = -gamma_12/tau_eta -alpha_12/(tau_eta*z);
C_14 = -lambda_1*tau_eps*(alpha_12+gamma_12*z)/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2);
C_21 = 0;
C_22 = 1-beta_1/(z*tau_eta)-lambda_1*tau_1*(alpha_11+gamma_11*z)/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2);
C_23 = 0;
C_24 = -lambda_1*tau_1*(alpha_12+gamma_12*z)/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2);
C_31 = -gamma_21/tau_eta -alpha_21/(tau_eta*z);
C_32 = -lambda_2*tau_eps*(alpha_21+gamma_21*z)/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2);
C_33 = 1-delta_22/(z*tau_eta)-gamma_22/tau_eta;
C_34 = -lambda_2*tau_eps*(alpha_22+gamma_22*z)/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2);
C_41 = 0;
C_42 = -lambda_2*tau_2*(alpha_21+gamma_21*z)/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2);
C_43 = 0;
C_44 = 1-beta_2/(z*tau_eta)-lambda_2*tau_2*(alpha_22+gamma_22*z)/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2);
C = [C_11 C_12 C_13 C_14; C_21 C_22 C_23 C_24; C_31 C_32 C_33 C_34; C_41 C_42 C_43 C_44];
determinant = det(C);
[numerator_C,~] = numden(determinant);
p = sym2poly(numerator_C);
r = roots(p);

% Collect the roots
zeta_1 = r(8);
zeta_2 = r(7);
zeta_3 = r(6);
zeta_4 = r(5);
zeta_5 = r(4);
zeta_6 = r(3);
theta_1 = r(2)^(-1);
theta_2 = r(1)^(-1);

% Write z again as a scalar and obtain the matrix C(z)
for j = 1:length(z_vector)
    z = z_vector(j);
    C_11 = 1-delta_11/(z*tau_eta)-gamma_11/tau_eta;
    C_12 = -lambda_1*tau_eps*(alpha_11+gamma_11*z)/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2);
    C_13 = -gamma_12/tau_eta -alpha_12/(tau_eta*z);
    C_14 = -lambda_1*tau_eps*(alpha_12+gamma_12*z)/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2);
    C_21 = 0;
    C_22 = 1-beta_1/(z*tau_eta)-lambda_1*tau_1*(alpha_11+gamma_11*z)/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2);
    C_23 = 0;
    C_24 = -lambda_1*tau_1*(alpha_12+gamma_12*z)/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2);
    C_31 = -gamma_21/tau_eta -alpha_21/(tau_eta*z);
    C_32 = -lambda_2*tau_eps*(alpha_21+gamma_21*z)/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2);
    C_33 = 1-delta_22/(z*tau_eta)-gamma_22/tau_eta;
    C_34 = -lambda_2*tau_eps*(alpha_22+gamma_22*z)/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2);
    C_41 = 0;
    C_42 = -lambda_2*tau_2*(alpha_21+gamma_21*z)/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2);
    C_43 = 0;
    C_44 = 1-beta_2/(z*tau_eta)-lambda_2*tau_2*(alpha_22+gamma_22*z)/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2);
    C = [C_11 C_12 C_13 C_14; C_21 C_22 C_23 C_24; C_31 C_32 C_33 C_34; C_41 C_42 C_43 C_44];

    % Create handles for the case C(zeta_i)
    C_12_func = @(z) -lambda_1*tau_eps*(alpha_11+gamma_11*z)/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2);
    C_13_func = @(z) -gamma_12/tau_eta -alpha_12/(tau_eta*z);
    C_14_func = @(z) -lambda_1*tau_eps*(alpha_12+gamma_12*z)/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2);
    C_22_func = @(z) 1-beta_1/(z*tau_eta)-lambda_1*tau_1*(alpha_11+gamma_11*z)/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2);
    C_23_func = @(z) 0;
    C_24_func = @(z) -lambda_1*tau_1*(alpha_12+gamma_12*z)/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2);
    C_32_func = @(z) -lambda_2*tau_eps*(alpha_21+gamma_21*z)/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2);
    C_33_func = @(z) 1-delta_22/(z*tau_eta)-gamma_22/tau_eta;
    C_34_func = @(z) -lambda_2*tau_eps*(alpha_22+gamma_22*z)/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2);
    C_42_func = @(z) -lambda_2*tau_2*(alpha_21+gamma_21*z)/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2);
    C_43_func = @(z) 0;
    C_44_func = @(z) 1-beta_2/(z*tau_eta)-lambda_2*tau_2*(alpha_22+gamma_22*z)/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2);
    
    %% Solve the system of equations to solve for h's
    % Set up the system of 4 unknowns and 4 equations in matrix form
    % First set the primitives: first term in dg
    d1_first_func       = @(z) varphi_1*lambda_1*tau_eps/(rho*tau_eta*(1-rho*lambda_1)*(1-lambda_1*z));
    d2_first_func       = @(z) varphi_1*lambda_1*tau_1/(rho*tau_eta*(1-rho*lambda_1)*(1-lambda_1*z));
    d3_first_func       = @(z) varphi_2*lambda_2*tau_eps/(rho*tau_eta*(1-rho*lambda_2)*(1-lambda_2*z));
    d4_first_func       = @(z) varphi_2*lambda_2*tau_2/(rho*tau_eta*(1-rho*lambda_2)*(1-lambda_2*z));
    % Second term in dg
    d1_second_func      = @(z) -delta_11*lambda_1*((1-lambda_1*z)*tau_1+(1-rho*z)*tau_eps)/((1-lambda_1*z)*(1-rho*lambda_1)*tau_eta^2*z*(rho-lambda_1));
    d2_second_func      = @(z) delta_11*lambda_1*tau_1/((1-lambda_1*z)*(1-rho*lambda_1)*tau_eta^2);
    d3_second_func      = @(z) -alpha_21*lambda_2*((1-lambda_2*z)*tau_2+(1-rho*z)*tau_eps)/((1-lambda_2*z)*(1-rho*lambda_2)*tau_eta^2*z*(rho-lambda_2));
    d4_second_func      = @(z) alpha_21*lambda_2*tau_2/((1-lambda_2*z)*(1-rho*lambda_2)*tau_eta^2);
    % Third term in dg
    d1_third_func       = @(z) beta_1*lambda_1*tau_eps/((1-lambda_1*z)*(1-rho*lambda_1)*tau_eta^2);
    d2_third_func       = @(z) -beta_1*lambda_1*((1-rho*z)*tau_1+(1-lambda_1*z)*tau_eps)/((1-lambda_1*z)*(1-rho*lambda_1)*tau_eta^2*z*(rho-lambda_1));
    d3_third_func       = @(z) 0;
    d4_third_func       = @(z) 0;
    % Fourth term in dg
    d1_fourth_func       = @(z) -alpha_12*lambda_1*((1-lambda_1*z)*tau_1+(1-rho*z)*tau_eps)/((1-lambda_1*z)*(1-rho*lambda_1)*tau_eta^2*z*(rho-lambda_1));
    d2_fourth_func       = @(z) alpha_12*lambda_1*tau_1/((1-lambda_1*z)*(1-rho*lambda_1)*tau_eta^2);
    d3_fourth_func       = @(z) -delta_22*lambda_2*((1-lambda_2*z)*tau_2+(1-rho*z)*tau_eps)/((1-lambda_2*z)*(1-rho*lambda_2)*tau_eta^2*z*(rho-lambda_2));
    d4_fourth_func       = @(z) delta_22*lambda_2*tau_2/((1-lambda_2*z)*(1-rho*lambda_2)*tau_eta^2);
    % Fifth term in dg
    d1_fifth_func       = @(z) 0;
    d2_fifth_func       = @(z) 0;
    d3_fifth_func       = @(z) beta_2*lambda_2*tau_eps/((1-lambda_2*z)*(1-rho*lambda_2)*tau_eta^2);
    d4_fifth_func       = @(z) -beta_2*lambda_2*((1-rho*z)*tau_2+(1-lambda_2*z)*tau_eps)/((1-lambda_2*z)*(1-rho*lambda_2)*tau_eta^2*z*(rho-lambda_2));
    % Sixth term in dg
    d1_sixth_func       = @(z) -lambda_1*(1-rho*z)*tau_eps/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2*(1-rho*lambda_1));
    d2_sixth_func       = @(z) -lambda_1*(1-rho*z)*tau_1/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2*(1-rho*lambda_1));
    d3_sixth_func       = @(z) 0;
    d4_sixth_func       = @(z) 0;
    % Seventh term in dg
    d1_seventh_func     = @(z) 0;
    d2_seventh_func     = @(z) 0;
    d3_seventh_func     = @(z) -lambda_2*(1-rho*z)*tau_eps/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2*(1-rho*lambda_2));
    d4_seventh_func     = @(z) -lambda_2*(1-rho*z)*tau_2/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2*(1-rho*lambda_2));
    
    alpha_1 = @(z) C_22_func(z)*(C_33_func(z)*C_44_func(z)-C_34_func(z)*C_43_func(z)) - C_32_func(z)*(C_23_func(z)*C_44_func(z)-C_24_func(z)*C_43_func(z)) + C_42_func(z)*(C_23_func(z)*C_34_func(z)-C_24_func(z)*C_33_func(z));
    alpha_2 = @(z) C_12_func(z)*(C_33_func(z)*C_44_func(z)-C_34_func(z)*C_43_func(z)) - C_32_func(z)*(C_13_func(z)*C_44_func(z)-C_14_func(z)*C_43_func(z)) + C_42_func(z)*(C_13_func(z)*C_34_func(z)-C_14_func(z)*C_33_func(z));
    alpha_3 = @(z) C_12_func(z)*(C_23_func(z)*C_44_func(z)-C_24_func(z)*C_43_func(z)) - C_22_func(z)*(C_13_func(z)*C_44_func(z)-C_14_func(z)*C_43_func(z)) + C_42_func(z)*(C_13_func(z)*C_24_func(z)-C_14_func(z)*C_23_func(z));
    alpha_4 = @(z) C_12_func(z)*(C_23_func(z)*C_34_func(z)-C_24_func(z)*C_33_func(z)) - C_22_func(z)*(C_13_func(z)*C_34_func(z)-C_14_func(z)*C_33_func(z)) + C_32_func(z)*(C_13_func(z)*C_24_func(z)-C_14_func(z)*C_23_func(z));

    % Set up the system of equations
    % zeta_1
    RHS_zeta_1          =   d1_first_func(zeta_1) * alpha_1(zeta_1) - d2_first_func(zeta_1) * alpha_2(zeta_1) + d3_first_func(zeta_1) * alpha_3(zeta_1) - d4_first_func(zeta_1) * alpha_4(zeta_1);
    h110_zeta_1         = - d1_second_func(zeta_1) * alpha_1(zeta_1) + d2_second_func(zeta_1) * alpha_2(zeta_1) - d3_second_func(zeta_1) * alpha_3(zeta_1) + d4_second_func(zeta_1) * alpha_4(zeta_1);
    h120_zeta_1         = - d1_third_func(zeta_1) * alpha_1(zeta_1) + d2_third_func(zeta_1) * alpha_2(zeta_1) - d3_third_func(zeta_1) * alpha_3(zeta_1) + d4_third_func(zeta_1) * alpha_4(zeta_1);
    h210_zeta_1         = - d1_fourth_func(zeta_1) * alpha_1(zeta_1) + d2_fourth_func(zeta_1) * alpha_2(zeta_1) - d3_fourth_func(zeta_1) * alpha_3(zeta_1) + d4_fourth_func(zeta_1) * alpha_4(zeta_1);
    h220_zeta_1         = - d1_fifth_func(zeta_1) * alpha_1(zeta_1) + d2_fifth_func(zeta_1) * alpha_2(zeta_1) - d3_fifth_func(zeta_1) * alpha_3(zeta_1) + d4_fifth_func(zeta_1) * alpha_4(zeta_1);
    hlambda1_zeta_1     = - d1_sixth_func(zeta_1) * alpha_1(zeta_1) + d2_sixth_func(zeta_1) * alpha_2(zeta_1) - d3_sixth_func(zeta_1) * alpha_3(zeta_1) + d4_sixth_func(zeta_1) * alpha_4(zeta_1);
    hlambda2_zeta_1     = - d1_seventh_func(zeta_1) * alpha_1(zeta_1) + d2_seventh_func(zeta_1) * alpha_2(zeta_1) - d3_seventh_func(zeta_1) * alpha_3(zeta_1) + d4_seventh_func(zeta_1) * alpha_4(zeta_1);
    % zeta_2
    RHS_zeta_2          =   d1_first_func(zeta_2) * alpha_1(zeta_2) - d2_first_func(zeta_2) * alpha_2(zeta_2) + d3_first_func(zeta_2) * alpha_3(zeta_2) - d4_first_func(zeta_2) * alpha_4(zeta_2);
    h110_zeta_2         = - d1_second_func(zeta_2) * alpha_1(zeta_2) + d2_second_func(zeta_2) * alpha_2(zeta_2) - d3_second_func(zeta_2) * alpha_3(zeta_2) + d4_second_func(zeta_2) * alpha_4(zeta_2);
    h120_zeta_2         = - d1_third_func(zeta_2) * alpha_1(zeta_2) + d2_third_func(zeta_2) * alpha_2(zeta_2) - d3_third_func(zeta_2) * alpha_3(zeta_2) + d4_third_func(zeta_2) * alpha_4(zeta_2);
    h210_zeta_2         = - d1_fourth_func(zeta_2) * alpha_1(zeta_2) + d2_fourth_func(zeta_2) * alpha_2(zeta_2) - d3_fourth_func(zeta_2) * alpha_3(zeta_2) + d4_fourth_func(zeta_2) * alpha_4(zeta_2);
    h220_zeta_2         = - d1_fifth_func(zeta_2) * alpha_1(zeta_2) + d2_fifth_func(zeta_2) * alpha_2(zeta_2) - d3_fifth_func(zeta_2) * alpha_3(zeta_2) + d4_fifth_func(zeta_2) * alpha_4(zeta_2);
    hlambda1_zeta_2     = - d1_sixth_func(zeta_2) * alpha_1(zeta_2) + d2_sixth_func(zeta_2) * alpha_2(zeta_2) - d3_sixth_func(zeta_2) * alpha_3(zeta_2) + d4_sixth_func(zeta_2) * alpha_4(zeta_2);
    hlambda2_zeta_2     = - d1_seventh_func(zeta_2) * alpha_1(zeta_2) + d2_seventh_func(zeta_2) * alpha_2(zeta_2) - d3_seventh_func(zeta_2) * alpha_3(zeta_2) + d4_seventh_func(zeta_2) * alpha_4(zeta_2);
    % zeta_3
    RHS_zeta_3          =   d1_first_func(zeta_3) * alpha_1(zeta_3) - d2_first_func(zeta_3) * alpha_2(zeta_3) + d3_first_func(zeta_3) * alpha_3(zeta_3) - d4_first_func(zeta_3) * alpha_4(zeta_3);
    h110_zeta_3         = - d1_second_func(zeta_3) * alpha_1(zeta_3) + d2_second_func(zeta_3) * alpha_2(zeta_3) - d3_second_func(zeta_3) * alpha_3(zeta_3) + d4_second_func(zeta_3) * alpha_4(zeta_3);
    h120_zeta_3         = - d1_third_func(zeta_3) * alpha_1(zeta_3) + d2_third_func(zeta_3) * alpha_2(zeta_3) - d3_third_func(zeta_3) * alpha_3(zeta_3) + d4_third_func(zeta_3) * alpha_4(zeta_3);
    h210_zeta_3         = - d1_fourth_func(zeta_3) * alpha_1(zeta_3) + d2_fourth_func(zeta_3) * alpha_2(zeta_3) - d3_fourth_func(zeta_3) * alpha_3(zeta_3) + d4_fourth_func(zeta_3) * alpha_4(zeta_3);
    h220_zeta_3         = - d1_fifth_func(zeta_3) * alpha_1(zeta_3) + d2_fifth_func(zeta_3) * alpha_2(zeta_3) - d3_fifth_func(zeta_3) * alpha_3(zeta_3) + d4_fifth_func(zeta_3) * alpha_4(zeta_3);
    hlambda1_zeta_3     = - d1_sixth_func(zeta_3) * alpha_1(zeta_3) + d2_sixth_func(zeta_3) * alpha_2(zeta_3) - d3_sixth_func(zeta_3) * alpha_3(zeta_3) + d4_sixth_func(zeta_3) * alpha_4(zeta_3);
    hlambda2_zeta_3     = - d1_seventh_func(zeta_3) * alpha_1(zeta_3) + d2_seventh_func(zeta_3) * alpha_2(zeta_3) - d3_seventh_func(zeta_3) * alpha_3(zeta_3) + d4_seventh_func(zeta_3) * alpha_4(zeta_3);
    % zeta_4
    RHS_zeta_4          =   d1_first_func(zeta_4) * alpha_1(zeta_4) - d2_first_func(zeta_4) * alpha_2(zeta_4) + d3_first_func(zeta_4) * alpha_3(zeta_4) - d4_first_func(zeta_4) * alpha_4(zeta_4);
    h110_zeta_4         = - d1_second_func(zeta_4) * alpha_1(zeta_4) + d2_second_func(zeta_4) * alpha_2(zeta_4) - d3_second_func(zeta_4) * alpha_3(zeta_4) + d4_second_func(zeta_4) * alpha_4(zeta_4);
    h120_zeta_4         = - d1_third_func(zeta_4) * alpha_1(zeta_4) + d2_third_func(zeta_4) * alpha_2(zeta_4) - d3_third_func(zeta_4) * alpha_3(zeta_4) + d4_third_func(zeta_4) * alpha_4(zeta_4);
    h210_zeta_4         = - d1_fourth_func(zeta_4) * alpha_1(zeta_4) + d2_fourth_func(zeta_4) * alpha_2(zeta_4) - d3_fourth_func(zeta_4) * alpha_3(zeta_4) + d4_fourth_func(zeta_4) * alpha_4(zeta_4);
    h220_zeta_4         = - d1_fifth_func(zeta_4) * alpha_1(zeta_4) + d2_fifth_func(zeta_4) * alpha_2(zeta_4) - d3_fifth_func(zeta_4) * alpha_3(zeta_4) + d4_fifth_func(zeta_4) * alpha_4(zeta_4);
    hlambda1_zeta_4     = - d1_sixth_func(zeta_4) * alpha_1(zeta_4) + d2_sixth_func(zeta_4) * alpha_2(zeta_4) - d3_sixth_func(zeta_4) * alpha_3(zeta_4) + d4_sixth_func(zeta_4) * alpha_4(zeta_4);
    hlambda2_zeta_4     = - d1_seventh_func(zeta_4) * alpha_1(zeta_4) + d2_seventh_func(zeta_4) * alpha_2(zeta_4) - d3_seventh_func(zeta_4) * alpha_3(zeta_4) + d4_seventh_func(zeta_4) * alpha_4(zeta_4);
    % zeta_5
    RHS_zeta_5          =   d1_first_func(zeta_5) * alpha_1(zeta_5) - d2_first_func(zeta_5) * alpha_2(zeta_5) + d3_first_func(zeta_5) * alpha_3(zeta_5) - d4_first_func(zeta_5) * alpha_4(zeta_5);
    h110_zeta_5         = - d1_second_func(zeta_5) * alpha_1(zeta_5) + d2_second_func(zeta_5) * alpha_2(zeta_5) - d3_second_func(zeta_5) * alpha_3(zeta_5) + d4_second_func(zeta_5) * alpha_4(zeta_5);
    h120_zeta_5         = - d1_third_func(zeta_5) * alpha_1(zeta_5) + d2_third_func(zeta_5) * alpha_2(zeta_5) - d3_third_func(zeta_5) * alpha_3(zeta_5) + d4_third_func(zeta_5) * alpha_4(zeta_5);
    h210_zeta_5         = - d1_fourth_func(zeta_5) * alpha_1(zeta_5) + d2_fourth_func(zeta_5) * alpha_2(zeta_5) - d3_fourth_func(zeta_5) * alpha_3(zeta_5) + d4_fourth_func(zeta_5) * alpha_4(zeta_5);
    h220_zeta_5         = - d1_fifth_func(zeta_5) * alpha_1(zeta_5) + d2_fifth_func(zeta_5) * alpha_2(zeta_5) - d3_fifth_func(zeta_5) * alpha_3(zeta_5) + d4_fifth_func(zeta_5) * alpha_4(zeta_5);
    hlambda1_zeta_5     = - d1_sixth_func(zeta_5) * alpha_1(zeta_5) + d2_sixth_func(zeta_5) * alpha_2(zeta_5) - d3_sixth_func(zeta_5) * alpha_3(zeta_5) + d4_sixth_func(zeta_5) * alpha_4(zeta_5);
    hlambda2_zeta_5     = - d1_seventh_func(zeta_5) * alpha_1(zeta_5) + d2_seventh_func(zeta_5) * alpha_2(zeta_5) - d3_seventh_func(zeta_5) * alpha_3(zeta_5) + d4_seventh_func(zeta_5) * alpha_4(zeta_5);
    % zeta_6
    RHS_zeta_6          =   d1_first_func(zeta_6) * alpha_1(zeta_6) - d2_first_func(zeta_6) * alpha_2(zeta_6) + d3_first_func(zeta_6) * alpha_3(zeta_6) - d4_first_func(zeta_6) * alpha_4(zeta_6);
    h110_zeta_6         = - d1_second_func(zeta_6) * alpha_1(zeta_6) + d2_second_func(zeta_6) * alpha_2(zeta_6) - d3_second_func(zeta_6) * alpha_3(zeta_6) + d4_second_func(zeta_6) * alpha_4(zeta_6);
    h120_zeta_6         = - d1_third_func(zeta_6) * alpha_1(zeta_6) + d2_third_func(zeta_6) * alpha_2(zeta_6) - d3_third_func(zeta_6) * alpha_3(zeta_6) + d4_third_func(zeta_6) * alpha_4(zeta_6);
    h210_zeta_6         = - d1_fourth_func(zeta_6) * alpha_1(zeta_6) + d2_fourth_func(zeta_6) * alpha_2(zeta_6) - d3_fourth_func(zeta_6) * alpha_3(zeta_6) + d4_fourth_func(zeta_6) * alpha_4(zeta_6);
    h220_zeta_6         = - d1_fifth_func(zeta_6) * alpha_1(zeta_6) + d2_fifth_func(zeta_6) * alpha_2(zeta_6) - d3_fifth_func(zeta_6) * alpha_3(zeta_6) + d4_fifth_func(zeta_6) * alpha_4(zeta_6);
    hlambda1_zeta_6     = - d1_sixth_func(zeta_6) * alpha_1(zeta_6) + d2_sixth_func(zeta_6) * alpha_2(zeta_6) - d3_sixth_func(zeta_6) * alpha_3(zeta_6) + d4_sixth_func(zeta_6) * alpha_4(zeta_6);
    hlambda2_zeta_6     = - d1_seventh_func(zeta_6) * alpha_1(zeta_6) + d2_seventh_func(zeta_6) * alpha_2(zeta_6) - d3_seventh_func(zeta_6) * alpha_3(zeta_6) + d4_seventh_func(zeta_6) * alpha_4(zeta_6);
    
    % Matrix form
    LHS_matrix =   [h110_zeta_1 h120_zeta_1 h210_zeta_1 h220_zeta_1 hlambda1_zeta_1 hlambda2_zeta_1;...
                    h110_zeta_2 h120_zeta_2 h210_zeta_2 h220_zeta_2 hlambda1_zeta_2 hlambda2_zeta_2;...
                    h110_zeta_3 h120_zeta_3 h210_zeta_3 h220_zeta_3 hlambda1_zeta_3 hlambda2_zeta_3;...
                    h110_zeta_4 h120_zeta_4 h210_zeta_4 h220_zeta_4 hlambda1_zeta_4 hlambda2_zeta_4;...
                    h110_zeta_5 h120_zeta_5 h210_zeta_5 h220_zeta_5 hlambda1_zeta_5 hlambda2_zeta_5;...
                    h110_zeta_6 h120_zeta_6 h210_zeta_6 h220_zeta_6 hlambda1_zeta_6 hlambda2_zeta_6];
                    
    RHS_matrix =   [RHS_zeta_1; RHS_zeta_2; RHS_zeta_3; RHS_zeta_4; RHS_zeta_5; RHS_zeta_6];

    % Solving for the 4 free constants
    h         = LHS_matrix^(-1)*RHS_matrix;
    x1        = h(1);
    x2        = h(2);
    x3        = h(3);
    x4        = h(4);
    x5        = h(5);
    x6        = h(6);
    
    D_1  =  varphi_1*lambda_1*tau_eps/(rho*tau_eta*(1-rho*lambda_1)*(1-lambda_1*z)) - ...
                    x1 * delta_11*lambda_1*((1-lambda_1*z)*tau_1+(1-rho*z)*tau_eps)/((1-lambda_1*z)*(1-rho*lambda_1)*tau_eta^2*z*(rho-lambda_1)) + ...
                    x2 * beta_1*lambda_1*tau_eps/((1-lambda_1*z)*(1-rho*lambda_1)*tau_eta^2) - ...
                    x3 * alpha_12*lambda_1*((1-lambda_1*z)*tau_1+(1-rho*z)*tau_eps)/((1-lambda_1*z)*(1-rho*lambda_1)*tau_eta^2*z*(rho-lambda_1)) - ...
                    x5 * lambda_1*(1-rho*z)*tau_eps/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2*(1-rho*lambda_1));
    D_2  =  varphi_1*lambda_1*tau_1/(rho*tau_eta*(1-rho*lambda_1)*(1-lambda_1*z)) + ...
                    x1 * delta_11*lambda_1*tau_1/((1-lambda_1*z)*(1-rho*lambda_1)*tau_eta^2) - ...
                    x2 * beta_1*lambda_1*((1-rho*z)*tau_1+(1-lambda_1*z)*tau_eps)/((1-lambda_1*z)*(1-rho*lambda_1)*tau_eta^2*z*(rho-lambda_1)) + ...
                    x3 * alpha_12*lambda_1*tau_1/((1-lambda_1*z)*(1-rho*lambda_1)*tau_eta^2) - ...
                    x5 * lambda_1*(1-rho*z)*tau_1/((z-lambda_1)*(1-lambda_1*z)*rho*tau_eta^2*(1-rho*lambda_1));
    D_3  =  varphi_2*lambda_2*tau_eps/(rho*tau_eta*(1-rho*lambda_2)*(1-lambda_2*z)) - ...
                    x1 * alpha_21*lambda_2*((1-lambda_2*z)*tau_2+(1-rho*z)*tau_eps)/((1-lambda_2*z)*(1-rho*lambda_2)*tau_eta^2*z*(rho-lambda_2)) - ...
                    x3 * delta_22*lambda_2*((1-lambda_2*z)*tau_2+(1-rho*z)*tau_eps)/((1-lambda_2*z)*(1-rho*lambda_2)*tau_eta^2*z*(rho-lambda_2)) + ...
                    x4 * beta_2*lambda_2*tau_eps/((1-lambda_2*z)*(1-rho*lambda_2)*tau_eta^2) - ...
                    x6 * lambda_2*(1-rho*z)*tau_eps/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2*(1-rho*lambda_2));
    D_4  =  varphi_2*lambda_2*tau_2/(rho*tau_eta*(1-rho*lambda_2)*(1-lambda_2*z)) + ...
                    x1 * alpha_21*lambda_2*tau_2/((1-lambda_2*z)*(1-rho*lambda_2)*tau_eta^2) + ...
                    x3 * delta_22*lambda_2*tau_2/((1-lambda_2*z)*(1-rho*lambda_2)*tau_eta^2) - ...
                    x4 * beta_2*lambda_2*((1-rho*z)*tau_2+(1-lambda_2*z)*tau_eps)/((1-lambda_2*z)*(1-rho*lambda_2)*tau_eta^2*z*(rho-lambda_2)) - ...
                    x6 * lambda_2*(1-rho*z)*tau_2/((z-lambda_2)*(1-lambda_2*z)*rho*tau_eta^2*(1-rho*lambda_2));
    
    D = [D_1; D_2; D_3; D_4];
    
    %% Obtain the policy functions
    hz  = C^(-1) * D;

    %% To obtain the Psi's, write it in form of h_g(z)*(1-theta_1*z)*(1-theta_2*z)
    LHS_1(j) = hz(1)*(1-theta_1*z)*(1-theta_2*z);
    LHS_2(j) = hz(2)*(1-theta_1*z)*(1-theta_2*z);
    LHS_3(j) = hz(3)*(1-theta_1*z)*(1-theta_2*z);
    LHS_4(j) = hz(4)*(1-theta_1*z)*(1-theta_2*z);

end

%% Check that the result is in fact linear
% Check for two values of z
PsiTilde1           = [1 z_vector(1); 1 z_vector(2)]^(-1)*LHS_1(1:2)';
PsiTildeCompare1    = [1 z_vector(2); 1 z_vector(3)]^(-1)*LHS_1(2:3)';
Compare1            = max(abs(PsiTilde1-PsiTildeCompare1));
% Check for two different values of z
PsiTilde2           = [1 z_vector(1); 1 z_vector(2)]^(-1)*LHS_2(1:2)';
PsiTildeCompare2    = [1 z_vector(2); 1 z_vector(3)]^(-1)*LHS_2(2:3)';
Compare2            = max(abs(PsiTilde2-PsiTildeCompare2));
% Check for two different values of z
PsiTilde3           = [1 z_vector(1); 1 z_vector(2)]^(-1)*LHS_3(1:2)';
PsiTildeCompare3    = [1 z_vector(2); 1 z_vector(3)]^(-1)*LHS_3(2:3)';
Compare3            = max(abs(PsiTilde3-PsiTildeCompare3));
% Check for two different values of z
PsiTilde4          = [1 z_vector(1); 1 z_vector(2)]^(-1)*LHS_4(1:2)';
PsiTildeCompare4    = [1 z_vector(2); 1 z_vector(3)]^(-1)*LHS_4(2:3)';
Compare4            = max(abs(PsiTilde4-PsiTildeCompare4));

%% Psi matrix
PhiTilde_mat = [PsiTilde1(1)+PsiTilde2(1) PsiTilde1(2)+PsiTilde2(2); 
                PsiTilde3(1)+PsiTilde4(1) PsiTilde3(2)+PsiTilde4(2)];
PsiTilde_mat = [PsiTilde1(1) PsiTilde1(2); 
                PsiTilde3(1) PsiTilde3(2)];

% Obtain the Phi's
Phi1                = [1-theta_1/rho 1-theta_2/rho; theta_2*(theta_1/rho-1) theta_1*(theta_2/rho-1)]^(-1) * PhiTilde_mat(1,:)';
Phi2                = [1-theta_1/rho 1-theta_2/rho; theta_2*(theta_1/rho-1) theta_1*(theta_2/rho-1)]^(-1) * PhiTilde_mat(2,:)';
Phi_mat             = [Phi1'; Phi2'];

% Obtain the Psi's
Psi1                = [1-theta_1/rho 1-theta_2/rho; theta_2*(theta_1/rho-1) theta_1*(theta_2/rho-1)]^(-1) * PsiTilde_mat(1,:)';
Psi2                = [1-theta_1/rho 1-theta_2/rho; theta_2*(theta_1/rho-1) theta_1*(theta_2/rho-1)]^(-1) * PsiTilde_mat(2,:)';
Psi_mat             = [Psi1'; Psi2'];

