clear all
close all
clc

z_vector       = [1 2 3]; % Guess linear shape
T              = 10;

%% NK model parameters
beta        = 0.99;                                                 % discount factor
theta       = 0.85;                                                 % Calvo pricing friction
sigma       = 1;                                                    % intertemporal elasticity of substitution
varphi      = 1;                                                    % inverse of Frisch elasticity
phi_pi      = 1.5;                                                  % inflation coefficient in Taylor rule
phi_y       = 0.1;                                                % output gap coefficient in Taylor rule
kappa       = (1-theta)*(1-theta*beta)/theta*(varphi+sigma);     % slope NKPC
rho         = 0.8;                                                  % perceived persistence of monetary policy shock
tau         = 0.1924;                                                 % profit tax rate
lambda      = 0.37;                                                 % share of HtM
s           = 0.96;                                             % probability of being unconstrained tomorrow, given unconstrained today
chi         = 1+varphi*(1-tau/lambda);                         % elasticity of constrained's consumption to aggregate income
delta       = 1+(chi-1)*(1-s)/(1-lambda*chi);                   % effective discount in aggregate Euler condition
varsigma    = sigma*(1-lambda*chi)/(1-lambda);

%% Model beyond FIRE parameters
sigma_1     = 3.66048024012006;                                                  % consumer signal dispersion
sigma_2     = sigma_1;                                                    % firm signal dispersion
sigma_eta   = 1;                                                    % variance of monetary policy shock
tau_1       = 1/sigma_1;                                            % precision of consumers' signal
tau_2       = tau_1;                                            % precision of firms' signal
tau_eta     = 1/sigma_eta;                                          % precision of exogenous process

%% Reduced-form parameters
varphi_1    = -beta*(1-lambda)/(sigma*(1-lambda*chi));                     % PE effect consumers
varphi_2    = 0;                                                    % PE effect firms
beta_1      = beta*s;
beta_2      = beta*theta;
gamma_11    = 1-beta-phi_y*beta*(1-lambda)/(sigma*(1-lambda*chi));
gamma_12    = -phi_pi*beta*(1-lambda)/(sigma*(1-lambda*chi));
gamma_21    = kappa*theta;
gamma_22    = 1-theta;
alpha_11    = beta*(delta-s);
alpha_12    = beta*(1-lambda)/(sigma*(1-lambda*chi));
alpha_21    = 0;
alpha_22    = 0;
delta_11    = beta_1+alpha_11;
delta_12    = alpha_12;
delta_21    = alpha_21;
delta_22    = beta_2+alpha_22;

%% Eigenvalues of (1-Kalman Gain) * rho
lambda_1    = 0.5*(1/rho+rho+tau_1/(rho*tau_eta)-sqrt((1/rho+rho+tau_1/(rho*tau_eta))^2-4));
lambda_2    = lambda_1;

%% Matrices
[Psi_mat,vartheta_1,vartheta_2,~,~,~,~] = Psis(lambda_1,lambda_2,rho,tau_1,...
    tau_2,tau_eta,beta_1,beta_2,varphi_1,varphi_2,gamma_11,gamma_12,gamma_21,gamma_22,...
    delta_11,delta_12,delta_21,delta_22,z_vector);

%% Impulse responses
[~,~,A,B]   = IRFs(T,sigma_eta,rho,vartheta_1,vartheta_2,Psi_mat,phi_y,phi_pi,1);
Atilde      = [varsigma+phi_y phi_pi; -kappa 1];
Btilde      = [varsigma*delta 1; 0 beta];
Ctilde      = [-1; 0];
Deltabar    = Atilde^(-1)*Btilde;
Varphibar   = Atilde^(-1)*Ctilde;

LHS = Deltabar^(-1)*(B-Varphibar);
RHS = A*B + rho*B;

omega_vec = [0:0.001:1];
check = ones(length(omega_vec),length(omega_vec));
omega_bpi = NaN(length(omega_vec),length(omega_vec));
parfor_progress(length(omega_vec));
for k = 1:length(omega_vec)
    parfor j = 1:length(omega_vec)
        omega_f11       = omega_vec(k);
        omega_f12       = real((LHS(1)-omega_f11*RHS(1))/RHS(2));
        omega_f21       = omega_vec(j);
        omega_f22       = real((LHS(2)-omega_f21*RHS(1))/RHS(2));
        Omega_f         = [omega_f11 omega_f12; omega_f21 omega_f22];
        Omega_b         = real((eye(2) - Deltabar*Omega_f*A)*A); omega_b11 = Omega_b(1,1);omega_b12 = Omega_b(1,2);omega_b21 = Omega_b(2,1);omega_b22 = Omega_b(2,2);
        omega_by(k,j)   = ((varsigma+phi_y)*omega_b11+phi_pi*omega_b21)/varsigma;
        omega_bpi(k,j)  = ((varsigma+phi_y)*omega_b12+phi_pi*omega_b22)/varsigma;
        omega_fy(k,j)   = (varsigma*delta*omega_f11 + omega_f21)/varsigma;
        omega_fpi(k,j)  = (varsigma*delta*omega_f12 + omega_f22-1)/varsigma;
        term            = omega_by(k,j)*omega_fy(k,j);
        c               = omega_by(k,j);
        b               = -1;
        a               = omega_fy(k,j);
        r               = roots([a b c]);
        zeta            = min(r);
        if r(1)>1 && r(2)>0 && r(2)<1 && omega_by(k,j)>0 && omega_fy(k,j)>0 
            check(k,j) = 0;
        end
    end
    parfor_progress;
end

indices             = find(omega_bpi);
[min_val, min_ind]  = min(abs(omega_bpi(indices)));
[row, col]          = ind2sub(size(omega_bpi), indices(min_ind));

%% Figure 4A

figure(1)
clf; % Clears previous figure
% Adjust figure size to make it more rectangular
set(gcf, 'Position', [100, 100, 800, 500]); % [left, bottom, width, height]
pbaspect([1.6 1 1]); % Ensure same aspect ratio
% Use imagesc to ensure the full matrix is displayed
imagesc(omega_vec, omega_vec, check);
% Remove colormap for binary shading
colormap(gray);
caxis([0 1]);  % Keep binary contrast
% Flip the Y-axis so that (0,0) is in the southwest corner
set(gca, 'YDir', 'normal');
% Format axes
axis equal;
xlim([omega_vec(1) omega_vec(end)]);
ylim([omega_vec(1) omega_vec(end)]);
xticks([0 0.2 0.4 0.6 0.8 1]); % Set specific X-axis ticks
yticks([0 0.2 0.4 0.6 0.8 1]); % Set specific Y-axis ticks
% Set axis labels with LaTeX formatting
xlabel('$\omega_{f,21}$', 'Interpreter', 'latex', 'FontSize', 18);
ylabel('$\omega_{f,11}$', 'Interpreter', 'latex', 'FontSize', 18);
% Improve font and line width
set(gca, 'FontSize', 16, 'LineWidth', 1.5);
% Print the figure with higher resolution
print(figure(1), '-dpdf', '-painters', '-bestfit', '-r300', ...
    'Figures/Figure_4A.pdf');

%% Figure 4B

omega_f11 = 0.2;
omega_f12 = real((LHS(1)-omega_f11*RHS(1))/RHS(2));
omega_f21 = 0.2;
omega_f22 = real((LHS(2)-omega_f21*RHS(1))/RHS(2));
Omega_f   = [omega_f11 omega_f12; omega_f21 omega_f22];
Omega_b   = real((eye(2) - Deltabar*Omega_f*A)*A); omega_b11 = Omega_b(1,1);omega_b12 = Omega_b(1,2);omega_b21 = Omega_b(2,1);omega_b22 = Omega_b(2,2);
omega_by  = ((varsigma+phi_y)*omega_b11+phi_pi*omega_b21)/varsigma;
omega_bpi = ((varsigma+phi_y)*omega_b12+phi_pi*omega_b22)/varsigma;
omega_fy  = (varsigma*delta*omega_f11 + omega_f21)/varsigma;
omega_fpi = (varsigma*delta*omega_f12 + omega_f22-1)/varsigma;

c = omega_by;
b = -1;
a = omega_fy;
r = roots([a b c]);

zeta = min(r);
temp = 1/varsigma + omega_fpi+omega_bpi*zeta^2*omega_fy^2/omega_by^2;

rescale1 = - zeta/omega_by*temp*(zeta*omega_fy/omega_by)^(1-1);
rescale2 = -1/varsigma*delta^(1-1);
for t=1:T
    FG(t) = - zeta/omega_by*temp*(zeta*omega_fy/omega_by)^(t-1)/rescale1;
    FG_FIRE(t) = -1/varsigma*delta^(t-1)/rescale2;
end

figure(2)
plot(0:T-1,abs(FG),'k','LineWidth',2)
hold on
plot(0:T-1,abs(FG_FIRE),'--k','LineWidth',2)
hold off
grid on
pbaspect([1 1 1])
xlabel('Quarters');
ylabel('Effect of FG on quarter $\tau$', 'Interpreter', 'latex');
legend('Beyond FIRE','FIRE')
set(gca,'FontSize',16)
orient(figure(2),'landscape')
print(figure(2),'-dpdf','-painters','-bestfit','-r0','Figures/Figure_4B.pdf')
