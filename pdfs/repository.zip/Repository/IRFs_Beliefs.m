function [a,i_eps,A,B] = IRFs_Beliefs(T,sigma_eps,theta_1,theta_2,rho_hat,Psi_mat,phi_pi,phi_y,gamma,size)

% Construct the different matrices
Phi     = [theta_1 0; 0 theta_2];
Omega   = [1-theta_1/rho_hat; 1-theta_2/rho_hat];
Q       = Psi_mat;
A       = Q * Phi * Q^(-1);
B       = Q * Omega;

% input the eta interest rate shocks
epsilon         = zeros(T,1);
epsilon(1)      = -sqrt(sigma_eps)*size;
epsilon(2:end)  = 0;

% aggregate action process
a       = NaN(T,2)';
a(:,1)  = B * gamma * epsilon(1);
for j = 2:T
    a(:,j) = A * a(:,j-1);
end
% Check if Stationary Proces
eigenvalue_check_2 = max(abs(eig(A)));
if eigenvalue_check_2 > 1
    disp(['Caution! Non-stationary process: spectral radius >1:' num2str(eigenvalue_check_2)])
end

for t = 1:T
        i_eps(t)     = phi_pi * a(2,t)  +   phi_y * a(1,t) ;
end