function [x,i,A,B] = IRFs(T,sigma_eta,rho,vartheta_1,vartheta_2,Psi_mat,phi_y,phi_pi,size)

% Construct the different matrices
Phi     = [vartheta_1 0; 0 vartheta_2];
Omega   = [1-vartheta_1/rho; 1-vartheta_2/rho];
Q       = Psi_mat;
A       = Q * Phi * Q^(-1);
B       = Q * Omega;

% input the eta interest rate shocks
eta     = zeros(T,1);
eta(1)  = -sqrt(sigma_eta)*size;

% input the AR(1) process
v      = NaN(T,1);
v(1)   = eta(1);
for j = 2:T
    v(j) = rho * v(j-1) + eta(j);
end
% aggregate action process
x       = NaN(T,2)';
x(:,1)  = B * v(1);
for j = 2:T
    x(:,j) = A * x(:,j-1) + B * v(j);
end
% Check if Stationary Proces
eigenvalue_check = max(abs(eig(A)));
if eigenvalue_check > 1
    disp(['Caution! Non-stationary process: spectral radius >1:' num2str(eigenvalue_check)])
end

for t = 1:T
        i(t)     = phi_pi * x(2,t)  +   phi_y * x(1,t)  + v(t);
end