clear all
close all
clc

%% NK model parameters
beta        = 0.99;                                                 % discount factor
theta       = 0.85;                                                 % Calvo pricing friction
sigma       = 1;                                                    % intertemporal elasticity of substitution
varphi      = 1;                                                    % inverse of Frisch elasticity
phi_pi      = 1.5;                                                  % inflation coefficient in Taylor rule
phi_y       = 0.1;                                                  % output gap coefficient in Taylor rule
kappa       = (1-theta)*(1-theta*beta)/theta*(varphi+sigma);        % slope NKPC
rho         = 0.8;                                                  % perceived persistence of monetary policy shock
tau         = 0.1924;                                                 % profit tax rate
sigma_eta   = 1;                                                    % variance of monetary policy shock
tau_eta     = 1/sigma_eta;

%% Model beyond FIRE parameters
sigma_1     = 3.66048024012006;                                                  % consumer signal dispersion
sigma_2     = sigma_1;                                                    % firm signal dispersion
tau_1       = 1/sigma_1;                                            % precision of consumers' signal
tau_2       = 1/sigma_2;                                            % precision of firms' signal

%% Eigenvalues of (1-Kalman Gain) * rho
lambda_1    = 0.5*(1/rho+rho+tau_1/(rho*tau_eta)-sqrt((1/rho+rho+tau_1/(rho*tau_eta))^2-4));
lambda_2    = 0.5*(1/rho+rho+tau_2/(rho*tau_eta)-sqrt((1/rho+rho+tau_2/(rho*tau_eta))^2-4));

z_vector        = [1 2 3]; % Guess linear shape
lambda_vec      = tau:0.001:0.5;
Peak            = NaN(1,length(lambda_vec));
Peak_FIRE       = NaN(1,length(lambda_vec));
vartheta_vec    = NaN(1,length(lambda_vec));
T               = 17;

for k = 1:length(lambda_vec)
    lambda      = lambda_vec(k);                                                 % share of HtM
    s           = 0.96;                                             % probability of being unconstrained tomorrow, given unconstrained today
    chi         = 1+varphi*(1-tau/lambda);                         % elasticity of constrained's consumption to aggregate income
    delta       = 1+(chi-1)*(1-s)/(1-lambda*chi);                   % effective discount in aggregate Euler condition

    %% Reduced-form parameters
    varphi_1    = -beta*(1-lambda)/(sigma*(1-lambda*chi));                     % PE effect consumers
    varphi_2    = 0;                                                    % PE effect firms
    beta_1      = beta*s;
    beta_2      = beta*theta;
    gamma_11    = 1-beta-phi_y*beta*(1-lambda)/(sigma*(1-lambda*chi));
    gamma_12    = -phi_pi*beta*(1-lambda)/(sigma*(1-lambda*chi));
    gamma_21    = kappa*theta;
    gamma_22    = 1-theta;
    alpha_11    = beta*(delta-s);
    alpha_12    = beta*(1-lambda)/(sigma*(1-lambda*chi));
    alpha_21    = 0;
    alpha_22    = 0;
    delta_11    = beta_1+alpha_11;
    delta_12    = alpha_12;
    delta_21    = alpha_21;
    delta_22    = beta_2+alpha_22;

    %% Matrices
    [Psi_mat,vartheta_1,vartheta_2,~,~,~,~] = Psis(lambda_1,lambda_2,rho,tau_1,...
        tau_2,tau_eta,beta_1,beta_2,varphi_1,varphi_2,gamma_11,gamma_12,gamma_21,gamma_22,...
        delta_11,delta_12,delta_21,delta_22,z_vector);

    %% Impulse responses
    size = 1; % 100 b.p.
    [x,~,A,B]                   = IRFs(T,sigma_eta,rho,vartheta_1,vartheta_2,Psi_mat,phi_y,phi_pi,size);
    output_gap                  = x(1,:);
    [x_FIRE,~,A_FIRE,B_FIRE]    = IRFs(T,sigma_eta,rho,0,0,Psi_mat,phi_y,phi_pi,size);
    output_gap_FIRE             = x_FIRE(1,:);

    %% Statistics
    Peak(k)         = max(output_gap);
    Peak_FIRE(k)    = max(output_gap_FIRE);
    Cumsum(k)       = sum(output_gap);
    Cumsum_FIRE(k)  = sum(output_gap_FIRE);
    vartheta_vec(k) = vartheta_1;
end

Ratio_peak          = Peak/Peak(1);
Ratio_peak_FIRE     = Peak_FIRE/Peak_FIRE(1);
Ratio_cumsum        = Cumsum/Cumsum(1);
Ratio_cumsum_FIRE   = Cumsum_FIRE/Cumsum_FIRE(1);

disp(['Amplification: ' num2str(real(Ratio_peak(179)))])
disp(['Amplification FIRE: ' num2str(real(Ratio_peak_FIRE(179)))])
disp(['Cumsum: ' num2str(real(Ratio_cumsum(179)))])
disp(['Cumsum FIRE: ' num2str(real(Ratio_cumsum_FIRE(179)))])

% Figure 1C
figure(1)
plot(lambda_vec,abs(Ratio_peak),'k','LineWidth',2)
hold on
plot(lambda_vec,abs(Ratio_peak_FIRE),'--k','LineWidth',2)
hold off
grid on
pbaspect([3 1 1])
xlabel('Share of Hand-to-Mouth (\lambda)');
ylabel('Peak Effect, Output');
legend('Beyond FIRE','FIRE','Location','northwest')
set(gca,'FontSize',16)
orient(figure(1),'landscape')
print(figure(1),'-dpdf','-painters','-bestfit','-r0','Figures/Figure_1C.pdf')

% Figure 1D
figure(4)
plot(lambda_vec,abs(Ratio_cumsum),'k','LineWidth',2)
hold on
plot(lambda_vec,abs(Ratio_cumsum_FIRE),'--k','LineWidth',2)
hold off
grid on
pbaspect([3 1 1])
xlabel('Share of Hand-to-Mouth (\lambda)');
ylabel('Cumulative Effect, Output');
legend('Beyond FIRE','FIRE','Location','northwest')
set(gca,'FontSize',16)
orient(figure(4),'landscape')
print(figure(4),'-dpdf','-painters','-bestfit','-r0','Figures/Figure_1D.pdf')

%% NK model parameters
lambda      = 0.37;                                                 % share of HtM
s           = 0.96;                                             % probability of being unconstrained tomorrow, given unconstrained today
chi         = 1+varphi*(1-tau/lambda);                         % elasticity of constrained's consumption to aggregate income
delta       = 1+(chi-1)*(1-s)/(1-lambda*chi);                   % effective discount in aggregate Euler condition
varsigma    = sigma*(1-lambda*chi)/(1-lambda);

%% Reduced-form parameters
varphi_1    = -beta*(1-lambda)/(sigma*(1-lambda*chi));                     % PE effect consumers
varphi_2    = 0;                                                    % PE effect firms
beta_1      = beta*s;
beta_2      = beta*theta;
gamma_11    = 1-beta-phi_y*beta*(1-lambda)/(sigma*(1-lambda*chi));
gamma_12    = -phi_pi*beta*(1-lambda)/(sigma*(1-lambda*chi));
gamma_21    = kappa*theta;
gamma_22    = 1-theta;
alpha_11    = beta*(delta-s);
alpha_12    = beta*(1-lambda)/(sigma*(1-lambda*chi));
alpha_21    = 0;
alpha_22    = 0;
delta_11    = beta_1+alpha_11;
delta_12    = alpha_12;
delta_21    = alpha_21;
delta_22    = beta_2+alpha_22;

%% Matrices
[Psi_mat,vartheta_1,vartheta_2,~,~,~,~] = Psis(lambda_1,lambda_2,rho,tau_1,...
    tau_2,tau_eta,beta_1,beta_2,varphi_1,varphi_2,gamma_11,gamma_12,gamma_21,gamma_22,...
    delta_11,delta_12,delta_21,delta_22,z_vector);

%% Impulse responses
[x,i,A,B]                       = IRFs(T,sigma_eta,rho,vartheta_1,vartheta_2,Psi_mat,phi_y,phi_pi,size);
output_gap                      = x(1,:);
[x_FIRE,i_FIRE,A_FIRE,B_FIRE]   = IRFs(T,sigma_eta,rho,0,0,Psi_mat,phi_y,phi_pi,size);
output_gap_FIRE                 =  x_FIRE(1,:);

%% Figures
% Load data from Excel file
excel_data  = xlsread('RRorig_quarterly.xlsx', 'Standardized_Size_Expansionary');
ramey_unemp = excel_data(:, 4);  % 4th column: new line
unemp_low   = excel_data(:, 5);  % 5th column: lower confidence bound
unemp_high  = excel_data(:, 6); % 6th column: upper confidence bound
ramey_i     = excel_data(:, 1);  % 4th column: new line
i_low       = excel_data(:, 2);  % 5th column: lower confidence bound
i_high      = excel_data(:, 3); % 6th column: upper confidence bound

T_new       = length(ramey_unemp);

% Figure 1B
adjust_size = (-0.25)/(i(1)*4); % theoretical response adjusted to 25bp
figure(2)
hold on;
% Shaded confidence band
h_fill = fill([0:T_new-1, fliplr(0:T_new-1)], [unemp_low', fliplr(unemp_high')], [0.8, 0.8, 0.8], 'EdgeColor', 'none', 'FaceAlpha', 0.3);
% New line
h_new = plot(0:T_new-1, ramey_unemp, 'b', 'LineWidth', 2);
% Original FIRE line
h_fire = plot(0:T-1, real(output_gap_FIRE * adjust_size), '--k', 'LineWidth', 2);
% Beyond FIRE dashed line
h_beyond = plot(0:T-1, real(output_gap * adjust_size), 'k', 'LineWidth', 2);
hold off;
grid on;
pbaspect([3 1 1]);
xlabel('Quarters');
ylabel('Impulse Response, Output');
legend([h_beyond, h_fire, h_new, h_fill], 'Beyond FIRE', 'FIRE', 'Ramey (2016)', '90% Confidence Band', 'Location', 'northeast');
set(gca, 'FontSize', 16);
orient(figure(2), 'landscape');
print(figure(2),'-dpdf','-painters','-bestfit','-r0','Figures/Figure_1B.pdf')

% Figure 1A
figure(3)
hold on;
% Shaded confidence band
h_fill = fill([0:T_new-1, fliplr(0:T_new-1)], [i_low', fliplr(i_high')], [0.8, 0.8, 0.8], 'EdgeColor', 'none', 'FaceAlpha', 0.3);
% New line
h_new = plot(0:T_new-1, ramey_i, 'b', 'LineWidth', 2);
% Original FIRE line
h_fire = plot(0:T-1, real(i_FIRE * 4 * adjust_size), '--k', 'LineWidth', 2);
% Beyond FIRE dashed line
h_beyond = plot(0:T-1, real(i * 4 * adjust_size), 'k', 'LineWidth', 2);
hold off;
grid on;
pbaspect([3 1 1]);
xlabel('Quarters');
ylabel('Impulse Response, Policy Rate');
legend([h_beyond, h_fire, h_new, h_fill], 'Beyond FIRE', 'FIRE', 'Ramey (2016)', '90% Confidence Band', 'Location', 'southeast');
set(gca, 'FontSize', 16);
orient(figure(3), 'landscape');
print(figure(3),'-dpdf','-painters','-bestfit','-r0','Figures/Figure_1A.pdf')

