clear all; close all; clc

% Keep computer working
system('caffeinate -dims &');

compute = 1; % if compute = 1, loop over policy space; if = 0, load results
grids   = 0.0001;

if compute == 1

    % Policy tools space
    phi_pi_vec       = 2:-grids:0;
    phi_y_vec        = 0:grid:2;
    determinacy      = NaN(numel(phi_pi_vec), numel(phi_y_vec), 2);
    determinacy_FIRE = NaN(numel(phi_pi_vec), numel(phi_y_vec), 2);
    Nja              = numel(phi_pi_vec);
    Nka              = numel(phi_y_vec);

    % Parameters to solve the model
    z_vector = [1 2 3];
    LHS_1    = NaN(1, length(z_vector));
    LHS_2    = LHS_1;

    %% -- Model parameters
    beta    = 0.99;   % discount factor
    theta   = 0.85;   % Calvo pricing friction
    sigma   = 1;      % intertemporal elasticity of substitution
    varphi  = 1;
    kappa   = (1-theta)*(1-theta*beta)/theta*(varphi+sigma);  % slope NKPC
    rho     = 0.8;

    sigma_1   = 3.66048024012006;  % consumer signal dispersion
    sigma_2   = sigma_1;          % firm signal dispersion
    sigma_eta = 1;                % variance of monetary policy shock
    tau_1     = 1/sigma_1;        % precision of consumers' signal
    tau_2     = tau_1;            % precision of firms' signal
    tau_eta   = 1/sigma_eta;      % precision of exogenous process

    % Eigenvalues of (1-Kalman Gain) * rho
    lambda_1 = 0.5*(1/rho + rho + tau_1/(rho*tau_eta) - sqrt((1/rho + rho + tau_1/(rho*tau_eta))^2 - 4));
    lambda_2 = lambda_1;

    % Looping over RANK and HANK frameworks
    for la = 1:2
        % Precompute framework-specific parameters
        if la == 1
            tau    = 0;
            lambda = 0;
            s      = 1;
            chi    = 1;
            delta  = 1;
        else
            tau    = 0.1924;                       % profit tax rate
            lambda = 0.37;
            s      = 0.96;                         % probability of unconstrained next period
            chi    = 1 + varphi*(1 - tau/lambda);
            delta  = 1 + (chi - 1)*(1 - s)/(1 - lambda*chi);
        end

        parfor_progress(Nja);
        for ja = 1:Nja
            parfor ka = 1:Nka
                % Policy rule coefficients
                phi_pi = phi_pi_vec(ja);
                phi_y  = phi_y_vec(ka);

                %% Reduced-form parameters
                varphi_1 = -beta*(1-lambda)/(sigma*(1-lambda*chi));
                varphi_2 = 0;
                beta_1   = beta*s;
                beta_2   = beta*theta;
                gamma_11 = 1 - beta - phi_y*beta*(1-lambda)/(sigma*(1-lambda*chi));
                gamma_12 = -phi_pi*beta*(1-lambda)/(sigma*(1-lambda*chi));
                gamma_21 = kappa*theta;
                gamma_22 = 1 - theta;
                alpha_11 = beta*(delta - s);
                alpha_12 = beta*(1-lambda)/(sigma*(1-lambda*chi));
                alpha_21 = 0;
                alpha_22 = 0;
                delta_11 = beta_1 + alpha_11;
                delta_12 = alpha_12;
                delta_21 = alpha_21;
                delta_22 = beta_2 + alpha_22;

                % Solve model and collect Psis
                [Psi_mat, vartheta_1, vartheta_2, zeta_1, zeta_2, zeta_3, zeta_4] = ...
                    Psis(lambda_1, lambda_2, rho, tau_1, tau_2, tau_eta, beta_1, beta_2, ...
                         varphi_1, varphi_2, gamma_11, gamma_12, gamma_21, gamma_22, ...
                         delta_11, delta_12, delta_21, delta_22, z_vector);

                % Determinacy in noisy-information model
                Phi   = [vartheta_1, 0; 0, vartheta_2];
                Q     = Psi_mat;
                A     = Q * Phi * Q^(-1);
                if max(abs(eig(A))) > 1 || any(abs([zeta_1, zeta_2, zeta_3, zeta_4, lambda_1, lambda_2]) > 1)
                    determinacy(ja, ka, la) = 0;
                else
                    determinacy(ja, ka, la) = 1;
                end

                % Determinacy in FIRE model
                I     = eye(2);
                Gamma = [gamma_11, gamma_12; gamma_21, gamma_22];
                Delta = [delta_11, delta_12; delta_21, delta_22];
                if max(abs(eig((I - Gamma)\Delta))) > 1
                    determinacy_FIRE(ja, ka, la) = 0;
                else
                    determinacy_FIRE(ja, ka, la) = 1;
                end
            end
            parfor_progress;
        end
        parfor_progress(0);
    end

    % Store determinacy results
    RANK      = determinacy_FIRE(:, :, 1);
    HANK      = determinacy_FIRE(:, :, 2);
    RANKbFIRE = determinacy(:, :, 1);
    HANKbFIRE = determinacy(:, :, 2);

    save('Determinacy_super_RANK.mat',    'RANK',    '-v7.3');
    save('Determinacy_super_HANK.mat',    'HANK',    '-v7.3');
    save('Determinacy_super_RANKbFIRE.mat','RANKbFIRE','-v7.3');
    save('Determinacy_super_HANKbFIRE.mat','HANKbFIRE','-v7.3');
else
    load('Determinacy_super_RANK.mat');
    load('Determinacy_super_HANK.mat');
    load('Determinacy_super_RANKbFIRE.mat');
    load('Determinacy_super_HANKbFIRE.mat');
end

%% Figures
% Figure 3.A: Comparison RANK - HANK under FIRE
close all;
figure(1);
A   = RANK*2 + HANK*4;
map = [1 1 1; 0.7 0.7 0.7; 0 0 0];
image([phi_pi_vec(end), phi_pi_vec(1)], [phi_y_vec(1), phi_y_vec(end)], A);
colormap(map);
ylabel('\phi_\pi'); xlabel('\phi_y');
set(gca, 'YTick', 0:0.2:2, 'YTickLabel', 2:-0.2:0, 'FontSize', 16);
orient(figure(1), 'landscape');
print(figure(1), '-dpdf', '-painters', '-bestfit', '-r0', ...
      'Figures/Figure_3A.pdf');

% Figure 3.B: Comparison HANK under FIRE - HANK beyond FIRE
figure(2);
A   = HANK*2 + HANKbFIRE*4;
map = [1 1 1; 0.5 0.5 0.5; 0.7 0.5 0.7; 0.7 0.7 0.7; 0 0 0];
image([phi_pi_vec(end), phi_pi_vec(1)], [phi_y_vec(1), phi_y_vec(end)], A);
colormap(map);
ylabel('\phi_\pi'); xlabel('\phi_y');
set(gca, 'YTick', 0:0.2:2, 'YTickLabel', 2:-0.2:0, 'FontSize', 16);
orient(figure(2), 'landscape');
print(figure(2), '-dpdf', '-painters', '-bestfit', '-r0', ...
      'Figures/Figure_3B.pdf');
