clear all
close all
clc

% Calibration of beta_rev

z_vector        = [1 2 3]; % Guess linear shape
sigma_vec_1       = linspace(3.6,3.75,2000);
K               = length(sigma_vec_1);
diff = NaN(K,1);

%% NK model parameters
beta        = 0.99;                                                 % discount factor
theta       = 0.85;                                                 % Calvo pricing friction
sigma       = 1;                                                    % intertemporal elasticity of substitution
varphi      = 1;                                                    % inverse of Frisch elasticity
phi_pi      = 1.5;                                                  % inflation coefficient in Taylor rule
phi_y       = 0.1;                                                % output gap coefficient in Taylor rule
kappa       = (1-theta)*(1-theta*beta)/theta*(varphi+sigma);     % slope NKPC
rho         = 0.8;                                                  % perceived persistence of monetary policy shock
lambda      = 0.37;                                                 % share of HtM
s           = 0.96;                                             % probability of being unconstrained tomorrow, given unconstrained today
chi         = 1.48;                                                 % elasticity of constrained's consumption to aggregate income
tau         = lambda*(1-(chi-1)/varphi);                                                 % profit tax rate
delta       = 1+(chi-1)*(1-s)/(1-lambda*chi);                   % effective discount in aggregate Euler condition
varsigma    = sigma*(1-lambda*chi)/(1-lambda);
sigma_eta   = 1;    % variance of monetary policy shock
tau_eta     = 1/sigma_eta;                                          % precision of exogenous process

%% Reduced-form parameters
varphi_1    = -beta*(1-lambda)/(sigma*(1-lambda*chi));                     % PE effect consumers
varphi_2    = 0;                                                    % PE effect firms
beta_1      = beta*s;
beta_2      = beta*theta;
gamma_11    = 1-beta-phi_y*beta*(1-lambda)/(sigma*(1-lambda*chi));
gamma_12    = -phi_pi*beta*(1-lambda)/(sigma*(1-lambda*chi));
gamma_21    = kappa*theta;
gamma_22    = 1-theta;
alpha_11    = beta*(delta-s);
alpha_12    = beta*(1-lambda)/(sigma*(1-lambda*chi));
alpha_21    = 0;
alpha_22    = 0;
delta_11    = beta_1+alpha_11;
delta_12    = alpha_12;
delta_21    = alpha_21;
delta_22    = beta_2+alpha_22;

clear beta theta sigma varphi phi_pi phi_y kappa lambda tau s chi delta varsigma

parfor_progress(K);
parfor k1 = 1:K
    %% Model beyond FIRE parameters
    sigma_1     = sigma_vec_1(k1);                                                  % consumer signal dispersion
    sigma_2 = sigma_1;
    tau_1       = 1/sigma_1;                                            % precision of consumers' signal
    tau_2       = 1/sigma_2;                                            % precision of firms' signal

    %% Eigenvalues of (1-Kalman Gain) * rho
    lambda_1    = 0.5*(1/rho+rho+tau_1/(rho*tau_eta)-sqrt((1/rho+rho+tau_1/(rho*tau_eta))^2-4));
    lambda_2    = 0.5*(1/rho+rho+tau_2/(rho*tau_eta)-sqrt((1/rho+rho+tau_2/(rho*tau_eta))^2-4));

    %% Matrices
    [Psi_mat,vartheta_1,vartheta_2,zeta_1,zeta_2,zeta_3,zeta_4] = Psis(lambda_1,lambda_2,rho,tau_1,...
        tau_2,tau_eta,beta_1,beta_2,varphi_1,varphi_2,gamma_11,gamma_12,gamma_21,gamma_22,...
        delta_11,delta_12,delta_21,delta_22,z_vector);

    [beta_rev_hh_pi] = Beta_Rev(Psi_mat(2,1),Psi_mat(2,2),vartheta_1,vartheta_2,rho,lambda_1);
    diff(k1) = (0.705 - beta_rev_hh_pi)^2;
    parfor_progress;
end
parfor_progress(0);


[minValue, linearIndex] = min(diff(:)); % Find the minimum value and its linear index
[row, col] = ind2sub(size(diff), linearIndex); % Convert the linear index to row and column indices

sigma_1     = sigma_vec_1(row);
sigma_2 = sigma_1;

clear col row minValue linearIndex diff K

%% Model beyond FIRE parameters                                                 % firm signal dispersion
tau_1       = 1/sigma_1;                                            % precision of consumers' signal
tau_2       = 1/sigma_2;                                            % precision of firms' signal
tau_eta     = 1/sigma_eta;                                          % precision of exogenous process

%% Eigenvalues of (1-Kalman Gain) * rho
lambda_1    = 0.5*(1/rho+rho+tau_1/(rho*tau_eta)-sqrt((1/rho+rho+tau_1/(rho*tau_eta))^2-4));
lambda_2    = 0.5*(1/rho+rho+tau_2/(rho*tau_eta)-sqrt((1/rho+rho+tau_2/(rho*tau_eta))^2-4));

%% Matrices
[Psi_mat,vartheta_1,vartheta_2,zeta_1,zeta_2,zeta_3,zeta_4] = Psis(lambda_1,lambda_2,rho,tau_1,...
    tau_2,tau_eta,beta_1,beta_2,varphi_1,varphi_2,gamma_11,gamma_12,gamma_21,gamma_22,...
    delta_11,delta_12,delta_21,delta_22,z_vector);

[beta_rev_hh_pi] = Beta_Rev(Psi_mat(2,1),Psi_mat(2,2),vartheta_1,vartheta_2,rho,lambda_1);