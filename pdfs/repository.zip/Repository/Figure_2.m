clear all
close all
clc

z_vector       = [1 2 3]; % Guess linear shape
T              = 30;

%% NK model parameters
beta        = 0.99;                                                 % discount factor
theta       = 0.85;                                                 % Calvo pricing friction
sigma       = 1;                                                    % intertemporal elasticity of substitution
varphi      = 1;                                                    % inverse of Frisch elasticity
phi_pi      = 1.5;                                                  % inflation coefficient in Taylor rule
phi_y       = 0.1;                                                  % output gap coefficient in Taylor rule
kappa       = (1-theta)*(1-theta*beta)/theta*(varphi+sigma);        % slope NKPC
rho         = 0.8;                                                  % perceived persistence of monetary policy shock
tau         = 0.1924;                                                 % profit tax rate
sigma_eta   = 1;                                                    % variance of monetary policy shock
tau_eta     = 1/sigma_eta;
lambda      = 0.37;                                                 % share of HtM
s           = 0.96;                                             % probability of being unconstrained tomorrow, given unconstrained today
chi         = 1+varphi*(1-tau/lambda);                         % elasticity of constrained's consumption to aggregate income
delta       = 1+(chi-1)*(1-s)/(1-lambda*chi);                   % effective discount in aggregate Euler condition

%% Model beyond FIRE parameters
sigma_1     = 3.66048024012006;                                                  % consumer signal dispersion
sigma_2     = sigma_1;                                                    % firm signal dispersion
tau_1       = 1/sigma_1;                                            % precision of consumers' signal
tau_2       = 1/sigma_2;                                            % precision of firms' signal

%% Eigenvalues of (1-Kalman Gain) * rho
lambda_1    = 0.5*(1/rho+rho+tau_1/(rho*tau_eta)-sqrt((1/rho+rho+tau_1/(rho*tau_eta))^2-4));
lambda_2    = 0.5*(1/rho+rho+tau_2/(rho*tau_eta)-sqrt((1/rho+rho+tau_2/(rho*tau_eta))^2-4));

%% Reduced-form parameters
varphi_1    = -beta*(1-lambda)/(sigma*(1-lambda*chi));                     % PE effect consumers
varphi_2    = 0;                                                    % PE effect firms
beta_1      = beta*s;
beta_2      = beta*theta;
gamma_11    = 1-beta-phi_y*beta*(1-lambda)/(sigma*(1-lambda*chi));
gamma_12    = -phi_pi*beta*(1-lambda)/(sigma*(1-lambda*chi));
gamma_21    = kappa*theta;
gamma_22    = 1-theta;
alpha_11    = beta*(delta-s);
alpha_12    = beta*(1-lambda)/(sigma*(1-lambda*chi));
alpha_21    = 0;
alpha_22    = 0;
delta_11    = beta_1+alpha_11;
delta_12    = alpha_12;
delta_21    = alpha_21;
delta_22    = beta_2+alpha_22;

%% Matrices
[Psi_mat,vartheta_1,vartheta_2,~,~,~,~] = Psis(lambda_1,lambda_2,rho,tau_1,...
    tau_2,tau_eta,beta_1,beta_2,varphi_1,varphi_2,gamma_11,gamma_12,gamma_21,gamma_22,...
    delta_11,delta_12,delta_21,delta_22,z_vector);

%% Impulse responses
adjusted_size               = 0.116488654030316;
[x,~,A,B]                   = IRFs(T,sigma_eta,rho,vartheta_1,vartheta_2,Psi_mat,phi_y,phi_pi,adjusted_size);
output_gap                  = x(1,:);
[x_FIRE,~,A_FIRE,B_FIRE]    = IRFs(T,sigma_eta,rho,0,0,Psi_mat,phi_y,phi_pi,adjusted_size);
output_gap_FIRE             = x_FIRE(1,:);

%% PE vs. GE
[PE_share,TE_effect,PE_effect,GE_effect]                     = PEvsGE_withPE(T,beta,s,rho,lambda,phi_y,phi_pi,sigma,lambda_1,vartheta_1,vartheta_2,Psi_mat);
[PE_share_FIRE,TE_effect_FIRE,PE_effect_FIRE,GE_effect_FIRE] = PEvsGE_withPE(T,beta,s,rho,lambda,phi_y,phi_pi,sigma,0.00001,0.000001,0.000001,Psi_mat);

for t = 1:T
    PE_effect_ratio(t) = PE_effect(t)/PE_effect_FIRE(t);
    GE_effect_ratio(t) = GE_effect(t)/GE_effect_FIRE(t);
end

% Figure 2B
figure(1)
plot(0:24,real(PE_share(1:25)),'k','LineWidth',2)
hold on
plot(0:24,real(PE_share_FIRE(1:25)),'--k','LineWidth',2)
hold off
grid on
pbaspect([3 1 1])
xlabel('Quarters');
ylabel('Share of PE Effect');
legend('Beyond FIRE','FIRE')
ylim([-0.1 1.1])
xlim([0 24])
set(gca,'FontSize',16)
xticks(0:4:24)  % Custom x-axis tick marks: 0, 4, 8, ... 24
orient(figure(1),'landscape')
print(figure(1),'-dpdf','-painters','-bestfit','-r0','Figures/Figure_2B.pdf')

% Figure 2A
figure(2)
x = [0:24];
Y = real([-PE_effect(1:25) -GE_effect(1:25)])*adjusted_size;
area(x,Y)
newcolors = [128 128 128; 220 220 220]/255;
colororder(newcolors)
grid on
pbaspect([3 1 1])
xlabel('Quarters','FontSize',16);
ylabel('PE, GE and Total Effects','FontSize',16);
legend({'PE Effect','GE Effect'},'FontSize',16)
xlim([0 24])
set(gca,'FontSize',16)
xticks(0:4:24)  % Custom x-axis tick marks: 0, 4, 8, ... 24
orient(figure(2),'landscape')
print(figure(2),'-dpdf','-painters','-bestfit','-r0','Figures/Figure_2A.pdf')

% Figure 2C
% Load data from Excel file
correct = - adjusted_size;
excel_data = xlsread('Holm.xlsx', 'Transformed');
partial_IV = excel_data(:, 8)*correct;  % 4th column: new line
partial_IV_low = excel_data(:, 10)*correct;  % 5th column: lower confidence bound
partial_IV_high = excel_data(:, 9)*correct; % 6th column: upper confidence bound
total = excel_data(:, 2)*correct;  % 4th column: new line
total_low = excel_data(:, 4)*correct;  % 5th column: lower confidence bound
total_high = excel_data(:, 3)*correct; % 6th column: upper confidence bound
PE_share_Holm =partial_IV./total;
T_new = 6;

figure(3)
hold on;
% Shaded confidence band
h_fill_partial = fill([0:T_new-1, fliplr(0:T_new-1)], [partial_IV_low', fliplr(partial_IV_high')], [0.8, 0.8, 0.8], 'EdgeColor', 'none', 'FaceAlpha', 0.3);
% New line
h_partial = plot(0:T_new-1, partial_IV, 'k', 'LineWidth', 2);
% Shaded confidence band
h_fill_total = fill([0:T_new-1, fliplr(0:T_new-1)], [total_low', fliplr(total_high')], [0.7, 0.85, 1], 'EdgeColor', 'none', 'FaceAlpha', 0.3);
% New line
h_total = plot(0:T_new-1, total, 'b', 'LineWidth', 2);
hold off;
grid on;
pbaspect([3 1 1]);
xlabel('Years');
xticks(0:T_new-1);
ylabel('Impulse Response, Consumption');
legend([h_total, h_fill_total, h_partial, h_fill_partial], 'Total Effect', 'Total Effect, 68% Confidence Bands', 'Direct Effect', 'Direct Effect, 68% Confidence Bands', 'Location', 'northwest');
set(legend, 'Box', 'off'); % Optional: remove legend box
ylim([-0.1 0.3])
set(gca, 'FontSize', 16);
orient(figure(3), 'landscape');
print(figure(3),'-dpdf','-painters','-bestfit','-r0','Figures/Figure_2C.pdf')

% Figure 2D
figure(4)
plot(0:5,real(PE_share_Holm),'k','LineWidth',2)
grid on
pbaspect([3 1 1])
xlabel('Years');
xticks(0:T_new-1);
ylabel('Share of PE Effect');
legend('Holm et al. (2021)')
ylim([-0.1 1.1])
set(gca,'FontSize',16)
orient(figure(4),'landscape')
print(figure(4),'-dpdf','-painters','-bestfit','-r0','Figures/Figure_2D.pdf')
