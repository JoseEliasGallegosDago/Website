function [a_xi,a_eps,i_xi,i_eps] = IRFs_public_and_private(T,sigma_eta,rho,theta_1,theta_2,Psi_mat,Phi_mat,phi_pi,phi_y,size)

%% Construct the different matrices
Lambda  = [theta_1 0; 0 theta_2];
Gamma   = [1-theta_1/rho; 1-theta_2/rho];
Q_xi    = Phi_mat;
Q_eps   = Psi_mat;

%% Shocks
% input the eta interest rate shocks
eta     = zeros(T,1);
eta(1)  = -sqrt(sigma_eta)*size;
% input the AR(1) process
xi      = NaN(T,1);
xi(1)   = eta(1);
for j = 2:T
    xi(j) = rho * xi(j-1) + eta(j);
end

% input the epsilon expectation shocks
eps     = zeros(T,1);
eps(1)  = -sqrt(sigma_eta)*0.25;
eps(2:end) = 0;

%% IRFs 
% aggregate action process
a_xi       = NaN(T,2)';
a_xi(:,1)  = Q_xi * Gamma * xi(1);
for j = 2:T
    a_xi(:,j) = Q_xi * Lambda * Q_xi^(-1) * a_xi(:,j-1) + Q_xi * Gamma * xi(j);
end

% aggregate action process
a_eps       = NaN(T,2)';
a_eps(:,1)  = Q_eps * Gamma * eps(1);
for j = 2:T
    a_eps(:,j) = Q_eps * Lambda * Q_eps^(-1) * a_eps(:,j-1);
end

for t = 1:T
    i_xi(t)     = phi_pi * a_xi(2,t)  +   phi_y * a_xi(1,t)  + xi(t);
    i_eps(t)    = phi_pi * a_eps(2,t) +   phi_y * a_eps(1,t);
end
