clear all
close all
clc

z_vector = [1 2 3]; % Guess linear shape

%% NK model parameters
beta        = 0.99;                                                 % discount factor
theta       = 0.85;                                                 % Calvo pricing friction
sigma       = 1;                                                    % intertemporal elasticity of substitution
varphi      = 1;                                                    % inverse of Frisch elasticity
phi_pi      = 1.5;                                                  % inflation coefficient in Taylor rule
phi_y       = 0.1;                                                 % output gap coefficient in Taylor rule
kappa       = (1-theta)*(1-theta*beta)/theta*(varphi+sigma);     % slope NKPC
rho         = 0.8;                                                  % persistence of monetary policy shock
tau         = 0.19;                                                 % profit tax rate
lambda      = 0.37;                                                 % share of HtM
s           = 0.96;                                             % probability of being unconstrained tomorrow, given unconstrained today
chi         = 1+varphi*(1-tau/lambda);                         % elasticity of constrained's consumption to aggregate income
delta       = 1+(chi-1)*(1-s)/(1-lambda*chi);                   % effective discount in aggregate Euler condition
varsigma    = sigma*(1-lambda*chi)/(1-lambda);

%% Model beyond FIRE parameters
gamma       = 1;
sigma_1     = (gamma^2+(1-gamma)^2)*3.66048024012006;                                                  % consumer signal dispersion
sigma_2     = sigma_1;                                                  % firm signal dispersion
sigma_eta   = 1;                                                    % variance of monetary policy shock
sigma_eps   = sigma_1;
tau_1       = 1/sigma_1;                                            % precision of consumers' signal
tau_2       = tau_1;                                            % precision of firms' signal
tau_eps     = tau_1;
tau_eta     = 1/sigma_eta;                                          % precision of exogenous process

%% Reduced-form parameters
varphi_1    = -beta*(1-lambda)/(sigma*(1-lambda*chi));                     % PE effect consumers
varphi_2    = 0;                                                    % PE effect firms
beta_1      = beta*s;
beta_2      = beta*theta;
gamma_11    = 1-beta-phi_y*beta*(1-lambda)/(sigma*(1-lambda*chi));
gamma_12    = -phi_pi*beta*(1-lambda)/(sigma*(1-lambda*chi));
gamma_21    = kappa*theta;
gamma_22    = 1-theta;
alpha_11    = beta*(delta-s);
alpha_12    = beta*(1-lambda)/(sigma*(1-lambda*chi));
alpha_21    = 0;
alpha_22    = 0;
delta_11    = beta_1+alpha_11;
delta_12    = alpha_12;
delta_21    = alpha_21;
delta_22    = beta_2+alpha_22;

%% Eigenvalues of (1-Kalman Gain) * rho
lambda_1    = 0.5*(1/rho+rho+tau_1/(rho*tau_eta)-sqrt((1/rho+rho+tau_1/(rho*tau_eta))^2-4));
lambda_2    = lambda_1;

%% Matrices
[Psi_mat,vartheta_1,vartheta_2,zeta_1,zeta_2,zeta_3,zeta_4] = Psis(lambda_1,lambda_2,rho,tau_1,...
    tau_2,tau_eta,beta_1,beta_2,varphi_1,varphi_2,gamma_11,gamma_12,gamma_21,gamma_22,...
    delta_11,delta_12,delta_21,delta_22,z_vector);

%% Impulse responses
adjust_size = 0.116488654030316;
T           = 20;
% Monetary Shock
[x,ir,A,B]  = IRFs(T,sigma_eta,rho,vartheta_1,vartheta_2,Psi_mat,phi_y,phi_pi,1);
OutputGap   = real(x(1,:));
Inflation   = real(x(2,:));
i           = real(ir);
% Animal Spirits Shock
[x_beliefs,i_eps,~,~]   = IRFs_Beliefs(T,sigma_eta,vartheta_1,vartheta_2,rho,Psi_mat,phi_pi,phi_y,gamma,1);
OutputGap_beliefs       = real(x_beliefs(1,:));
Inflation_beliefs       = real(x_beliefs(2,:));
i_beliefs               = real(i_eps);
% FIRE
[a,i_st,~,B_FIRE]       = IRFs(T,sigma_eta,rho,0,0,Psi_mat,phi_y,phi_pi,1);
OutputGap_standard      = real(a(1,:));
Inflation_standard      = real(a(2,:));
i_standard              = real(i_st);

save OutputGap_standard.mat OutputGap_standard i_standard

%% Figures
% Figure 5A
figure(1)
plot(1:T,real(OutputGap)*adjust_size,'k','LineWidth',2)
hold on
plot(1:T,real(OutputGap_beliefs)*adjust_size,'--k','LineWidth',2)
hold off
grid on
pbaspect([3 1 1])
xlabel('Quarters');
ylabel('Impulse Response, Output');
legend('Monetary Shock','Animal Spirits Shock')
set(gca,'FontSize',16)
orient(figure(1),'landscape')
print(figure(1),'-dpdf','-painters','-bestfit','-r0','Figures/Figure_5A.pdf')

% Figure 5B
figure(2)
plot(1:T,real(i)*4*adjust_size,'k','LineWidth',2)
hold on
plot(1:T,real(i_beliefs)*4*adjust_size,'--k','LineWidth',2)
hold off
grid on
pbaspect([3 1 1])
xlabel('Quarters');
ylabel('Impulse Response, Policy Rate');
legend('Monetary Shock','Animal Spirits Shock')
set(gca,'FontSize',16)
orient(figure(2),'landscape')
print(figure(2),'-dpdf','-painters','-bestfit','-r0','Figures/Figure_5B.pdf')

