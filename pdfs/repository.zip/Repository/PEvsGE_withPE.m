function [PE_share,TE,PE,GE] = PEvsGE_withPE(T,beta,s,rho,lambda,phi_y,phi_pi,sigma,lambda_1,vartheta_1,vartheta_2,Psi_mat)

psi_11 = Psi_mat(1,1);
psi_12 = Psi_mat(1,2);
psi_21 = Psi_mat(2,1);
psi_22 = Psi_mat(2,2);

% Terms on pi
termrho_pi       = psi_21 + psi_22;
termlambda_pi    = - psi_21*(rho-vartheta_1)*lambda_1^2*(1-rho*vartheta_1)/(rho^2*(1-lambda_1*vartheta_1)*(lambda_1-vartheta_1)) ...
                   - psi_22*(rho-vartheta_2)*lambda_1^2*(1-rho*vartheta_2)/(rho^2*(1-lambda_1*vartheta_2)*(lambda_1-vartheta_2));
termvartheta1_pi = psi_21*vartheta_1^2*(rho-lambda_1)*(1-rho*lambda_1)/(rho^2*(1-lambda_1*vartheta_1)*(lambda_1-vartheta_1));
termvartheta2_pi = psi_22*vartheta_2^2*(rho-lambda_1)*(1-rho*lambda_1)/(rho^2*(1-lambda_1*vartheta_2)*(lambda_1-vartheta_2));

% Terms on y
termrho_y       = psi_11 + psi_12;
termlambda_y    = - psi_11*(rho-vartheta_1)*lambda_1^2*(1-rho*vartheta_1)/(rho^2*(1-lambda_1*vartheta_1)*(lambda_1-vartheta_1)) ...
                   - psi_12*(rho-vartheta_2)*lambda_1^2*(1-rho*vartheta_2)/(rho^2*(1-lambda_1*vartheta_2)*(lambda_1-vartheta_2));
termvartheta1_y = psi_11*vartheta_1^2*(rho-lambda_1)*(1-rho*lambda_1)/(rho^2*(1-lambda_1*vartheta_1)*(lambda_1-vartheta_1));
termvartheta2_y = psi_12*vartheta_2^2*(rho-lambda_1)*(1-rho*lambda_1)/(rho^2*(1-lambda_1*vartheta_2)*(lambda_1-vartheta_2));

% Terms on v
termrho_v       = 1;
termlambda_v    = - lambda_1/rho;

% Terms on pi (discounted sum)
termrho_pids       = (psi_21 + psi_22)*rho/(1-beta*rho*s);
termlambda_pids    = psi_21*lambda_1*(rho-vartheta_1)...
                     *(rho*vartheta_1*(1-rho*beta*s*lambda_1*vartheta_1)-rho*lambda_1*(1-lambda_1*vartheta_1)-lambda_1*vartheta_1*(1-rho*beta*s))...
                     /(rho^2*(1-beta*s*vartheta_1)*(lambda_1-vartheta_1)*(1-lambda_1*vartheta_1)*(1-rho*beta*s))...
                   + psi_22*lambda_1*(rho-vartheta_2)...
                     *(rho*vartheta_2*(1-rho*beta*s*lambda_1*vartheta_2)-rho*lambda_1*(1-lambda_1*vartheta_2)-lambda_1*vartheta_2*(1-rho*beta*s))...
                     /(rho^2*(1-beta*s*vartheta_2)*(lambda_1-vartheta_2)*(1-lambda_1*vartheta_2)*(1-rho*beta*s));
termvartheta1_pids = psi_21*vartheta_1^3*(rho-lambda_1)*(1-rho*lambda_1)/(rho^2*(1-beta*s*vartheta_1)*(lambda_1-vartheta_1)*(1-lambda_1*vartheta_1));
termvartheta2_pids = psi_22*vartheta_2^3*(rho-lambda_1)*(1-rho*lambda_1)/(rho^2*(1-beta*s*vartheta_2)*(lambda_1-vartheta_2)*(1-lambda_1*vartheta_2));

% Terms on y (discounted sum)
termrho_yds       = (psi_11 + psi_12)*rho/(1-beta*rho*s);
termlambda_yds    = psi_11*lambda_1*(rho-vartheta_1)...
                     *(rho*vartheta_1*(1-rho*beta*s*lambda_1*vartheta_1)-rho*lambda_1*(1-lambda_1*vartheta_1)-lambda_1*vartheta_1*(1-rho*beta*s))...
                     /(rho^2*(1-beta*s*vartheta_1)*(lambda_1-vartheta_1)*(1-lambda_1*vartheta_1)*(1-rho*beta*s))...
                   + psi_12*lambda_1*(rho-vartheta_2)...
                     *(rho*vartheta_2*(1-rho*beta*s*lambda_1*vartheta_2)-rho*lambda_1*(1-lambda_1*vartheta_2)-lambda_1*vartheta_2*(1-rho*beta*s))...
                     /(rho^2*(1-beta*s*vartheta_2)*(lambda_1-vartheta_2)*(1-lambda_1*vartheta_2)*(1-rho*beta*s));
termvartheta1_yds = psi_11*vartheta_1^3*(rho-lambda_1)*(1-rho*lambda_1)/(rho^2*(1-beta*s*vartheta_1)*(lambda_1-vartheta_1)*(1-lambda_1*vartheta_1));
termvartheta2_yds = psi_12*vartheta_2^3*(rho-lambda_1)*(1-rho*lambda_1)/(rho^2*(1-beta*s*vartheta_2)*(lambda_1-vartheta_2)*(1-lambda_1*vartheta_2));

% Build TE and PE
TE       = NaN(T,1);
GE       = NaN(T,1);
PE       = NaN(T,1);
GE_share = NaN(T,1);
PE_share = NaN(T,1);

for t = 1:T
    PE(t) = - (1-lambda)*phi_pi/sigma * (termrho_pi*rho^(t-1) + termlambda_pi*lambda_1^(t-1) + termvartheta1_pi*vartheta_1^(t-1) + termvartheta2_pi*vartheta_2^(t-1)) ...
            - (1-lambda)*phi_y/sigma * (termrho_y*rho^(t-1) + termlambda_y*lambda_1^(t-1) + termvartheta1_y*vartheta_1^(t-1) + termvartheta2_y*vartheta_2^(t-1)) ...
            - (1-lambda)*(beta*s*phi_pi-1)/sigma * (termrho_pids*rho^(t-1) + termlambda_pids*lambda_1^(t-1) + termvartheta1_pids*vartheta_1^(t-1) + termvartheta2_pids*vartheta_2^(t-1)) ...
            - (1-lambda)*phi_y/sigma * (termrho_yds*rho^(t-1) + termlambda_yds*lambda_1^(t-1) + termvartheta1_yds*vartheta_1^(t-1) + termvartheta2_yds*vartheta_2^(t-1)) ...
            - (1-lambda)/(sigma*(1-rho*beta*s)) * (termrho_v*rho^(t-1) + termlambda_v*lambda_1^(t-1));
    Fpi(t) = (termrho_pi*rho^(t-1) + termlambda_pi*lambda_1^(t-1) + termvartheta1_pi*vartheta_1^(t-1) + termvartheta2_pi*vartheta_2^(t-1));
    Fy(t) = (termrho_y*rho^(t-1) + termlambda_y*lambda_1^(t-1) + termvartheta1_y*vartheta_1^(t-1) + termvartheta2_y*vartheta_2^(t-1));
    Fpids(t) = (termrho_pids*rho^(t-1) + termlambda_pids*lambda_1^(t-1) + termvartheta1_pids*vartheta_1^(t-1) + termvartheta2_pids*vartheta_2^(t-1));
    Fyds(t) = (termrho_yds*rho^(t-1) + termlambda_yds*lambda_1^(t-1) + termvartheta1_yds*vartheta_1^(t-1) + termvartheta2_yds*vartheta_2^(t-1));
    Fv(t) = (termrho_v*rho^(t-1) + termlambda_v*lambda_1^(t-1));
    TE(t) = psi_11/rho*(rho^t-vartheta_1^t) + psi_12/rho*(rho^t-vartheta_2^t);
    PE_share(t) = PE(t)/TE(t);
    GE_share(t) = 1-PE_share(t);
    GE(t) = TE(t) - PE(t);
end














